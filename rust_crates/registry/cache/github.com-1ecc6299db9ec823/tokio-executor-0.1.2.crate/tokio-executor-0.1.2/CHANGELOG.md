# 0.1.2 (March 30, 2018)

* Implement `Unpark` for `Box<Unpark>`.

# 0.1.1 (March 22, 2018)

* Optionally support futures 0.2.

# 0.1.0 (March 09, 2018)

* Initial release
