// For now, we need to keep the implmentation of Encoder in tokio_io.

pub use codec::Decoder;
