# 0.1.1 (June 13, 2018)

* Switch to tokio-codec (#360)

# 0.1.0 (Mar 23, 2018)

* Initial release
