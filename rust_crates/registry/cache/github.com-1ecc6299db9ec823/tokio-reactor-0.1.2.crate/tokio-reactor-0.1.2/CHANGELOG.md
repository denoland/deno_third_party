# 0.1.2 (June 13, 2018)

* Fix deadlock that can happen when shutting down (#409)
* Handle::default() lazily binds to reactor (#350)

# 0.1.1 (March 22, 2018)

* Fix threading bugs (#227)
* Fix notification bugs (#243)
* Optionally support futures 0.2 (#172)

# 0.1.0 (March 09, 2018)

* Initial release
